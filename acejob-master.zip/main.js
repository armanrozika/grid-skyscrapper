//This is HTML to be injected

const kiosk = (element)=>{
	let htmlDiv = `
	<div class="close">
		<p>x</p>
	</div>
	<div class="form__wraper">
		<p class="title">DO YOU WANT A CALLBACK?</p>
		<p class="title_back">Please give us your details and we will get back to you</p>
		<form id="form">
			<input class="input" name="username" type="text" placeholder="Your Name" required>
			<p class="err">Name is invalid</p>
			<input class="input" name="phone" type="text" placeholder="Phone" required>
			<p class="err">Phone number is invalid</p>
			<select name="" id="">
				<option value="content">I'm interested in Content</option>
				<option value="design">I'm interested in Design</option>
			</select>
			<input class="input" name="email" type="text" placeholder="Email" required>
			<p class="err">Email is invalid</p>
			<button class="callbtn">Call Now</button>
		</form>
	</div>
	<div class="minimised">
		<img src="phone.jpg" alt="">
		<p>Click here to get a call-back</p>
	</div>
	<div class="spinner">
		<img src="https://loading.io/spinners/double-ring/lg.double-ring-spinner.gif" alt="">
	</div>
	<div class="aftersubmit">
		<p>You will receive a call soon</p>
	</div>
`;

//INSERT ELEMENT TO HTML PAGE
let parentDiv = document.createElement('div');
parentDiv.innerHTML = htmlDiv;
parentDiv.classList.add('widget');


document.body.insertBefore(parentDiv, document.body.firstChild);

//STYLING
let idwidget = document.querySelector('.widget')	
idwidget.style.position = 'fixed';
idwidget.style.bottom = '10px';   
idwidget.style.right = '20px'; 	
idwidget.style.width = '335px'; 
idwidget.style.height = '467px';   
idwidget.style.background= '#285886';  
idwidget.style.borderRadius = '15px';   
idwidget.style.padding = '10px';  
idwidget.style.transition = 'all 300ms ease-in-out';
idwidget.style.transformOrigin = 'bottom';


let closebutton = document.querySelector(`.close`);
closebutton.style.position = 'absolute';
closebutton.style.display = 'flex';
closebutton.style.alignItems = 'center';
closebutton.style.justifyContent = 'center';
closebutton.style.top = '-14px';
closebutton.style.right = '-9px';
closebutton.style.width = '30px';
closebutton.style.height = '30px';
closebutton.style.borderRadius = '50%';
closebutton.style.background = '#215286';
closebutton.style.cursor = 'pointer';
closebutton.style.border = '2px solid #fff';

let closebuttonP =  document.querySelector('.close p');
closebuttonP.style.fontSize = '15px';
closebuttonP.style.fontWeight = 'bold';
closebuttonP.style.color = '#fff';

let formwrapP = document.querySelector('.form__wraper > p');
formwrapP.style.color = '#fff';
formwrapP.style.fontSize = '13px';
formwrapP.style.lineHeight = '2';

let titleP = document.querySelector('.title');
titleP.style.color = '#fff';
titleP.style.fontSize = '18px';
titleP.style.fontWeight = '500';
titleP.style.marginTop = '3px';

let titleback = document.querySelector('.title_back');
titleback.style.color = '#fff';
titleback.style.fontSize = '13px';


let idform = document.querySelector('#form')
idform.style.marginTop = '20px';
idform.style.textAlign = 'center';

let idinput = document.querySelectorAll('.input, select')
for(let i=0; i<idinput.length; i++){
	idinput[i].style.display = 'block';
	idinput[i].style.width = '100%';
    idinput[i].style.padding = '15px';
    idinput[i].style.color = 'rgb(53, 53, 53)';
	idinput[i].style.fontSize = '16px';
	idinput[i].style.border = 'none';
	idinput[i].style.borderRadius = '2px';
	idinput[i].style.background = 'rgb(180, 210, 235)';
}

let idselect = document.querySelector('select')
idselect.style.marginBottom = '30px'

let iderr = document.querySelectorAll('.err')
for(let i=0; i<iderr.length; i++){
	iderr[i].style.fontSize = '13px';
	iderr[i].style.marginBottom = '2px';
	iderr[i].style.marginTop = '5px';
	iderr[i].style.visibility = 'hidden';
	iderr[i].style.lineHeight = '2';
	iderr[i].style.color = '#ff6868';
	iderr[i].style.textAlign = 'left';
}

let idbtn = document.querySelector('.callbtn')
idbtn.style.marginTop = '0px';
idbtn.style.padding = '10px 20px';
idbtn.style.fontSize = '17px';
idbtn.style.fontWeight = '500';
idbtn.style.color = '#fff';
idbtn.style.background = '#00c4ff';
idbtn.style.borderRadius = '5px';
idbtn.style.border = 'none';
idbtn.style.cursor = 'pointer';

let idminimised = document.querySelector('.minimised');
idminimised.style.width = '100%';
idminimised.style.height = '34px';
idminimised.style.display = 'flex';
idminimised.style.alignItems = 'center';
idminimised.style.display = 'none';
idminimised.style.cursor = 'pointer';
idminimised.style.paddingLeft = '11px';

let idminimg = document.querySelector('.minimised img');
idminimg.style.width = 'auto';
idminimg.style.height = '100%';
idminimg.style.marginRight = '10px';

let idminip = document.querySelector('.minimised p');
idminip.style.fontSize = '18px';
idminip.style.fontWeight = '500';
idminip.style.color = '#fff';

let idspinner = document.querySelector('.spinner');
idspinner.style.position = 'absolute';
idspinner.style.top = '50%';
idspinner.style.left = '50%';
idspinner.style.transform = 'translate(-50%, -50%)';
idspinner.style.display = 'none';

let idaftersubmit = document.querySelector('.aftersubmit')
idaftersubmit.style.position = 'absolute';
idaftersubmit.style.top = '50%';
idaftersubmit.style.left = '50%';
idaftersubmit.style.transform = 'translate(-50%, -50%)';
idaftersubmit.style.display = 'none';
idaftersubmit.style.width = '100%';
idaftersubmit.style.textAlign = 'center';

let idaftersubmitp = document.querySelector('.aftersubmit p')
idaftersubmitp.style.color = '#fff';
idaftersubmitp.style.fontSize = '18px';
idaftersubmitp.style.fontWeight = '500';




//CONTROLLER FOR THE UI THROUGH JSON
//You can modify the UI by changing value of element object properties
const widget = document.querySelector('.widget')
const err = document.querySelectorAll('.err')
const closeBtn = document.querySelector('.close')


if(element.align == 'top'){
	widget.style.top = '50px';
}else if(element.align == 'bottom'){
	widget.style.bottom = '20px';
}else if(element.align == 'center' && element.position!='center'){
	widget.style.top = '50%'
	widget.style.transform = 'translateY(-50%)'
}

if(element.position == 'left'){
	widget.style.left = '20px'
	closeBtn.style.left = '-10px'
}else if(element.position == 'right'){
	widget.style.right = '20px'
}else if(element.position == 'center' &&  element.align!='center'){
	widget.style.left = '50%'
	widget.style.transform = 'translateX(-50%)'
}

if(element.align == 'center' && element.position == 'center'){
	widget.style.left = '50%';
	widget.style.top = '50%'
	widget.style.transform = 'translate(-50%, -50%)'
}

let inputInd = document.querySelectorAll('input')
for(let k = 0; k<inputInd.length; k++){
	if(element[inputInd[k].name] == false){
		inputInd[k].remove();
		err[k].remove();
	}
}

//decrease height & hide form when minimised

const formWraper = document.querySelector('.form__wraper')
const minimised = document.querySelector('.minimised')
const afterSubmit = document.querySelector('.aftersubmit')

closeBtn.addEventListener('click', ()=>{
	widget.style.height = '55px'
	//widget.style.transform  = 'scaleY(0.1)'
	formWraper.style.display = 'none'
	closeBtn.style.display = 'none'
	minimised.style.display = 'flex'
	afterSubmit.style.display = 'none'
});


//maximized
minimised.addEventListener('click', ()=>{
	widget.style.height = '467px'
	formWraper.style.display = 'block'
	closeBtn.style.display = 'flex'
	minimised.style.display = 'none'
});


//validate input
const inputs = document.querySelectorAll('input')

const patterns = {
	phone: /^\d{6,15}$/,
	username: /^[a-zA-Z]+$/,
	email: /^([a-z\d\.-]+)@([a-z\d-]+)\.([a-z]{2,8})(\.[a-z]{2,8})?$/
}

function validate(field, regex, error){
	if(regex.test(field,regex) == false){
		error.style.visibility = 'visible'
	}else if(regex.test(field,regex) == true){
		error.style.visibility = 'hidden'
	}
}


//form submission
const form = document.querySelector('form')
const callBtn = document.querySelector('.callbtn')

const spinner = document.querySelector('.spinner')

let validateAll = false;

form.addEventListener('submit', (e)=>{
	e.preventDefault();
});

callBtn.addEventListener('click', ()=>{
	for(let i=0; i<inputs.length; i++){
		validate(inputs[i].value, patterns[inputs[i].name], err[i])
	}
	//validate all
	for(let j=0; j<err.length; j++){
		if(err[j].style.visibility == 'visible'){
			validateAll = false;
			break;
		}else{
			validateAll = true;
		}
	}

	if(validateAll){
		formWraper.style.display = 'none'
		spinner.style.display = 'block'
		fetch('https://jsonplaceholder.typicode.com/posts',{
			method: 'POST'
		})
		.then(response => response.json())
		.then(json => {
			spinner.style.display = 'none'
			afterSubmit.style.display = 'block'
		})
	}else{
		spinner.style.display = 'none'
		formWraper.style.display = 'block'
	}
})

}



let element = {
	"align": "top",
	"position": "left",
	"username": true,
	"phone": true,
	"email": false,
	"background": '#215286'
};

kiosk(element);